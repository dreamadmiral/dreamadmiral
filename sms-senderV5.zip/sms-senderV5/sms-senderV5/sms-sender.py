import urllib.request
from colorama import Fore, Back, Style
import sys
import os
import os.path
import requests
import re
import time

# CONFIG

API_KEY = 'APIP867829z623i4'
API_UID= 'xxxxxxx'
COOLDOWN = 10  # In Seconds
ENDPOINT = 'https://yunpian.com/v2/sms/single_send.json'

# Functions


def getNums(fname):
    filename = os.path.join(os.getcwd(), fname)
    file = open(filename, 'r')
    count = 0
    arr = []
    for line in file:
        count += 1
        arr.append(line.strip())
    file.close()
    return (arr)


def Send(nums, msg, API_KEY, API_UID):
    failed = []
    count = count2 = 0
    for i in nums:
        count += 1
        count2 += 1
        if count2 == 100:
            count2 = 0
            print(Fore.BLUE+"Cooldown {} Secs\n".format(COOLDOWN), end="\r")
            time.sleep(COOLDOWN)
        HEADERS={"Accept": "application/json;charset=utf-8", "Content-Type":"application/x-www-form-urlencoded;charset=utf-8"}
        PARAMS = {
            'apiKey': API_KEY,
            'text': msg,
            'uid':API_UID,
            'mobile': i,
        }
        resp = requests.post(url=ENDPOINT, data=PARAMS, headers=HEADERS)
        result = resp.json()
        resultcode= int(result['code'])
        if resultcode == 0:
            stats= Fore.GREEN+'Success'+Style.RESET_ALL
        else:
            stats= Fore.RED+'Failed'+Style.RESET_ALL
        print(Fore.GREEN+'\033[1m>> [{}] '.format(count)+'Target: {}'.format(Fore.BLUE+i)+Fore.GREEN+'\tStatus: {}'.format(stats)+Fore.GREEN+'\t\033[1mRemarks: {}'.format(result['msg'])+Style.RESET_ALL ,end='\r')
        if resultcode != 200:
            failed.append(i)
            filename= os.path.join( os.getcwd(), 'error_log.txt')
            file = open(filename, 'w')
            for x in failed:
                file.write(x+'\n')
    success= len(nums) - len(failed)
    print(Fore.GREEN+'\033[K\033[1m>> '+Fore.YELLOW+'Total: {}'.format(len(nums))+Fore.GREEN+'\tSuccess: {}'.format(success)+Fore.RED+'\t Failed: {}'.format(len(failed))+Style.RESET_ALL)
    print(Fore.GREEN+'\033[1m>> Failed Numbers Stored in'+Fore.YELLOW+' error_log.txt'+Style.RESET_ALL)
    sys.exit()


def connect(host='http://fast.com'):
    try:
        urllib.request.urlopen(host)
        return True
    except:
        return False


print(Fore.GREEN+"""
    ███████╗███╗   ███╗███████╗    ███████╗███████╗███╗   ██╗██████╗ ███████╗██████╗ 
    ██╔════╝████╗ ████║██╔════╝    ██╔════╝██╔════╝████╗  ██║██╔══██╗██╔════╝██╔══██╗
    ███████╗██╔████╔██║███████╗    ███████╗█████╗  ██╔██╗ ██║██║  ██║█████╗  ██████╔╝
    ╚════██║██║╚██╔╝██║╚════██║    ╚════██║██╔══╝  ██║╚██╗██║██║  ██║██╔══╝  ██╔══██╗
    ███████║██║ ╚═╝ ██║███████║    ███████║███████╗██║ ╚████║██████╔╝███████╗██║  ██║
    ╚══════╝╚═╝     ╚═╝╚══════╝    ╚══════╝╚══════╝╚═╝  ╚═══╝╚═════╝ ╚══════╝╚═╝  ╚═╝"""+Fore.RED+"""                                                                     
    \033[1m★彡[ Author: """+Fore.GREEN+"""akshayitzme """+Fore.RED+"""	      Project: """+Fore.GREEN+"""𝚐𝚒𝚝𝚑𝚞𝚋.𝚌𝚘𝚖/𝚊𝚔𝚜𝚑𝚊𝚢𝚒𝚝𝚣𝚖𝚎/sms-sender"""+Fore.RED+""" ]彡★
""")


if connect():
    pass
else:
    print(Fore.RED+'\t\033[1m >> Internet not Connected !')
    sys.exit()
fname = input(Fore.GREEN+'>> Enter Filename: \033[0m')
if os.path.exists(fname):
    msg = input(Fore.GREEN+'\033[1m>> Enter Message: ')
    check = input(
        Fore.GREEN+'\033[1m>> Confirm to Send ? [ y for yes : n for No ] ')
    if check in ['n', 'N', 'No', 'no', 'NO']:
        sys.exit()
    numsAr = getNums(fname)
    Send(numsAr, msg, API_KEY, API_UID)
else:
    print(Fore.RED+'\033[1m>> File Doesnt Exist !')
    sys.exit()
